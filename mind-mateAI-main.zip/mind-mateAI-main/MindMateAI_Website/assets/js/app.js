// Mobile nav toggle
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.querySelector('.nav-toggle');
  const nav = document.querySelector('.nav');
  if (toggle) toggle.addEventListener('click', () => nav.classList.toggle('open'));

  // Sparklines
  const spark = document.getElementById('sparkline');
  if (spark) drawSparkline(spark, randomTrend(7));

  const moodSpark = document.getElementById('moodSpark');
  if (moodSpark) drawSparkline(moodSpark, randomTrend(14));
});

function drawSparkline(container, values){
  const width = container.clientWidth || 320;
  const height = 80;
  const max = Math.max(...values);
  const min = Math.min(...values);
  const pts = values.map((v,i)=>{
    const x = (i/(values.length-1)) * (width-10) + 5;
    const y = height - ((v-min)/(max-min||1)) * (height-20) - 10;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  container.innerHTML = `<svg width="${width}" height="${height}" role="img" aria-label="trend">
    <polyline points="${pts}" fill="none" stroke="currentColor" stroke-width="2"></polyline>
    <circle cx="${pts.split(' ').pop().split(',')[0]}" cy="${pts.split(' ').pop().split(',')[1]}" r="3" />
  </svg>`;
  container.style.color = getComputedStyle(document.documentElement).getPropertyValue('--brand');
}

function randomTrend(n){
  let v = 5, arr=[];
  for(let i=0;i<n;i++){ v += (Math.random()-0.4); v = Math.max(1, Math.min(10,v)); arr.push(v); }
  return arr;
}

// Demo chat (mock)
function openChat(){ document.getElementById('chatModal').style.display='grid'; document.getElementById('chatInput').focus(); }
function closeChat(){ document.getElementById('chatModal').style.display='none'; }
function demoChatSend(){
  const input = document.getElementById('chatInput');
  const win = document.getElementById('chatWindow');
  if(!input.value.trim()) return;
  const you = document.createElement('div'); you.className = 'chat-bubble you'; you.textContent = input.value; win.appendChild(you);
  setTimeout(()=>{
    const bot = document.createElement('div'); bot.className = 'chat-bubble bot'; bot.textContent = 'Thanks for sharing. What is one tiny step you can take in 5 minutes?'; win.appendChild(bot);
    win.scrollTop = win.scrollHeight;
  }, 400);
  input.value='';
}

// Fake forms
function fakeBook(form){ alert('Thanks '+form.name.value+'! We will email you a calendar invite.'); form.reset(); }
function fakeSubscribe(form){ alert('Subscribed! Please check your inbox.'); form.reset(); }
function fakeContact(form){ alert('Message sent. Our support will get back to you within 24 hours.'); form.reset(); }
function joinChallenge(name){ alert('Joined "'+name+'". Good luck!'); }

// Simple audio demo (placeholder)
function playDemo(){ const a = new Audio(); a.src = 'data:audio/mp3;base64,//uQZAAAAAAAAAAAAAAAAAAAA'; a.play().catch(()=>alert('Audio demo played.')); }