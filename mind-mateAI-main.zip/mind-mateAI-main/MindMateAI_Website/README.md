# MindMate AI — Website & Marketing Pack

This folder contains:
- A modern, responsive website (HTML/CSS/JS) with pages: Home, Product, Services, Contact, Blog, Community (bonus).
- Banner ads (728x90 and 300x250) in `assets/img/`.
- A one‑page web newsletter (`newsletter.html`) and a visual preview image `newsletter_preview.png`.
- Docs: Essay, Marketing Report, References, Monitor Days (in `/docs`).

## Local Preview
Open `index.html` in a browser.

## GitHub Pages (Live Preview)
1) Create a repo named `mindmate-ai-site`.  
2) Upload the folder contents.  
3) In repo settings → Pages → Select `main` branch `/root`.  
4) The live link will be shown (usually `https://<username>.github.io/mindmate-ai-site/`).